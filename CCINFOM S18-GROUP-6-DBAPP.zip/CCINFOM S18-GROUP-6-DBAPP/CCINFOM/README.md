## To Do
Connecting to sql
1. Change DBConnect class url, username and password.
2. DBConnect db = new DBConnect();

  
   whenever you use conn, do db.conn


Install connector/j on platform independent then put it in your referenced libraries.
- Driver
- Classes for all tables
- Reports
